/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1_ds;

import java.text.DecimalFormat;
import java.util.Random;

/**
 *
 * @author victor
 */
public class P1_DS extends Thread{

    //ObservableProvincias observable;
    ObservableSaldos observable;
    
    
    public P1_DS(ObservableSaldos _ob){  //Objeto principal: simulador de dinero en provincias
        observable = _ob;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rand=new Random();
        double dinero=0 + (250 - 0) * rand.nextDouble();
        ObservableSaldos miSaldo = new ObservableSaldos(dinero, "Granada");
        
        P1_DS miCliente = new P1_DS(miSaldo); 
        ObservadorNoSuscrito pant = new ObservadorNoSuscrito(miSaldo);
        miGrafica grafica = new miGrafica(miSaldo);
        
        miSaldo.addObserver(grafica);
        
        miCliente.start();
        
        pant.setVisible(true);
        pant.hebra.start();
        
        grafica.setVisible(true);
        
        //Parte opcional-------------------------------------------------------------------
        
        BotonSaldo boton = new BotonSaldo(miSaldo);
        Mapa miMapa = new Mapa();
        
        ObservableSaldos saldoAlmeria = new ObservableSaldos(dinero, "Almeria");
        ObservableSaldos saldoMalaga = new ObservableSaldos(dinero, "Malaga");
        ObservableSaldos saldoJaen = new ObservableSaldos(dinero, "Jaen");
        ObservableSaldos saldoCordoba = new ObservableSaldos(dinero, "Cordoba");
        ObservableSaldos saldoCadiz = new ObservableSaldos(dinero, "Cadiz");
        ObservableSaldos saldoSevilla = new ObservableSaldos(dinero, "Sevilla");
        ObservableSaldos saldoHuelva = new ObservableSaldos(dinero, "Huelva");
        
        P1_DS clienteAl = new P1_DS(saldoAlmeria);
        P1_DS clienteMa = new P1_DS(saldoMalaga);
        P1_DS clienteJa = new P1_DS(saldoJaen);
        P1_DS clienteCo = new P1_DS(saldoCordoba);
        P1_DS clienteCa = new P1_DS(saldoCadiz);
        P1_DS clienteSe = new P1_DS(saldoSevilla);
        P1_DS clienteHu = new P1_DS(saldoHuelva);
        
        saldoAlmeria.addObserver(miMapa);
        miSaldo.addObserver(miMapa);
        saldoJaen.addObserver(miMapa);
        saldoMalaga.addObserver(miMapa);
        saldoCordoba.addObserver(miMapa);
        saldoCadiz.addObserver(miMapa);
        saldoSevilla.addObserver(miMapa);
        saldoHuelva.addObserver(miMapa);
        
        miSaldo.addObserver(boton);
        
        clienteAl.start();
        clienteMa.start();
        clienteJa.start();
        clienteCo.start();
        clienteCa.start();
        clienteSe.start();
        clienteHu.start();
        
        miMapa.setVisible(true);
        boton.setVisible(true);
        
        Compuesto graficaBoton = new Compuesto(miSaldo);
        
        miSaldo.addObserver(graficaBoton);
        
        graficaBoton.setVisible(true);

    }


    
    @Override
    public void run(){
        Random rand=new Random();
        double dinero;
        
        while(true){
            dinero=-250 + (250 - (-250)) * rand.nextDouble();
            try {
                Thread.sleep(2500);
            }catch(java.lang.InterruptedException e){
                e.printStackTrace();
            }
            observable.aniadeSaldo(dinero);
        }
    }
    
}
