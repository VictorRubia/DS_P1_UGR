package p1_ds;

import java.util.Observable;

public class ObservableSaldos extends java.util.Observable {
        
    private double _saldo;
    private String _ubicacion;

    public ObservableSaldos(double saldo, String comunidad){
        super();
        _saldo = saldo;
        _ubicacion = comunidad;
    }

    public String getUbicacion() {
            return _ubicacion;
    }

    public double getState(){
        return _saldo;
    }

    public void setState(double saldo){
        _saldo = saldo;
    }

    public void aniadeSaldo(double saldo){
        _saldo += saldo;
        this.setChanged();    //Marcamos que el saldo ha cambiado 
        this.notifyObservers(); //y notificamos a todos los observadores que ha cambiado
    }
}