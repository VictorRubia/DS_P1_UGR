package Banca;

public class PrestamoEmpresas extends Prestamo {

    public PrestamoEmpresas(int _id, int _cantidad, int _anios){
            super(_id, _cantidad, _anios);
        }
}