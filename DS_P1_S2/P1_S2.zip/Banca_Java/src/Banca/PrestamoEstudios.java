package Banca;

public class PrestamoEstudios extends Prestamo {

    PrestamoEstudios(int _id, int _cantidad, int _anios){
        super(_id, _cantidad, _anios);
    }
}